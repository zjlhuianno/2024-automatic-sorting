#ifndef UART_TASK_H
#define UART_TASK_H

#include "main.h"
#include "usart.h"
#include <stdio.h>

extern void usart_task(void const * argument);
int fputc(int ch, FILE *f);

#endif
